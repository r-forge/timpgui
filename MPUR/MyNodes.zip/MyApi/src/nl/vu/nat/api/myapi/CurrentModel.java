/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package nl.vu.nat.api.myapi;

/**
 *
 * @author joris
 */
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import nl.vu.nat.tgmodels.tgm.Tgm;
import nl.vu.nat.tgmodels.tgo.Tgo;

public class CurrentModel {
   public static Tgm model;
   public static String datasetNames[];
   public static int numDat;
   public static Tgo opt;
   public static String modelName;

   public void CurrentModel() {
       model = null;
       datasetNames = null;
       numDat = 0;
       opt = null;
       modelName = null;
   }
   
   public Tgm Getmodel(){
       return model;
   }
   
   public String[] GetdatasetNames(){
       return datasetNames;
   }
   
   public int GetnumDat(){
       return numDat;
   }
   
   public Tgo Getopt(){
       return opt;
   }
   
   public String GetmodelName(){
       return modelName;
   }
   
   public void SetdatasetNames(String[] x) {
       this.datasetNames=x;
   }
   
   public void SetnumDat(int x) {
       this.numDat=x;
   }
   
   public void Setopt(Tgo x) {
       opt=x;
   }
   
   public void Setmodel(Tgm x) {
       model=x;
   }
   
   public void SetmodelName(String x) {
       modelName=x;
   }
   
    private List listeners = Collections.synchronizedList(new LinkedList());

   public void addPropertyChangeListener(PropertyChangeListener pcl) {
        listeners.add(pcl);
    }

    public void removePropertyChangeListener(PropertyChangeListener pcl) {
        listeners.remove(pcl);
    }

    private void fire(String propertyName, Object old, Object nue) {
        //Passing 0 below on purpose, so you only synchronize for one atomic call
        PropertyChangeListener[] pcls = (PropertyChangeListener[]) listeners.toArray(new PropertyChangeListener[0]);
        for (int i = 0; i < pcls.length; i++) {
            pcls[i].propertyChange(new PropertyChangeEvent(this,
                    propertyName, old, nue));
        }
    }
    
}
