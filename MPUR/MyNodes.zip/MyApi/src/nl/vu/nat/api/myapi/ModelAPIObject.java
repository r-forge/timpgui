/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package nl.vu.nat.api.myapi;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import nl.vu.nat.tgmodels.tgm.Tgm;

/**
 *
 * @author joris
 */

public final class ModelAPIObject {

    public static Tgm model;
    public static int numDat;
    public static String modelName;
    private static int count = 0;
    private final int index;

    public ModelAPIObject() {
       index = count++;
       model = null;
       numDat = 0;
       modelName = null;
    }
    
   public int getIndex() {
        return index;
   }
   
   public Tgm Getmodel(){
       return model;
   }
   
   public int GetnumDat(){
       return numDat;
   }
   
   public String GetmodelName(){
       return modelName;
   }
   
   public void SetnumDat(int x) {
       numDat=x;
   }
   
   public void Setmodel(Tgm x) {
       model=x;
   }
   
   public void SetmodelName(String x) {
       modelName=x;
   }
   
   private List listeners = Collections.synchronizedList(new LinkedList());

   public void addPropertyChangeListener(PropertyChangeListener pcl) {
        listeners.add(pcl);
    }

    public void removePropertyChangeListener(PropertyChangeListener pcl) {
        listeners.remove(pcl);
    }

    private void fire(String propertyName, Object old, Object nue) {
        //Passing 0 below on purpose, so you only synchronize for one atomic call
        PropertyChangeListener[] pcls = (PropertyChangeListener[]) listeners.toArray(new PropertyChangeListener[0]);
        for (int i = 0; i < pcls.length; i++) {
            pcls[i].propertyChange(new PropertyChangeEvent(this,
                    propertyName, old, nue));
        }
    }
    
}
