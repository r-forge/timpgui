/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.vu.nat.api.myapi;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import nl.vu.nat.tgmodels.tgo.Tgo;

/**
 *
 * @author joris
 */
public final class OptionsAPIObject {

    public static Tgo opt;
    public static String modelName;
    private static int count = 0;
    private final int index;

   public OptionsAPIObject() {
        opt = null;
        modelName = null;
        index = count++;
    }
    
   public int getIndex() {
        return index;
   }
    

    public Tgo Getopt() {
        return opt;
    }

    public String GetmodelName() {
        return modelName;
    }

    public void Setopt(Tgo x) {
        opt = x;
    }

    public void SetmodelName(String x) {
        modelName = x;
    }
    private List listeners = Collections.synchronizedList(new LinkedList());

    public void addPropertyChangeListener(PropertyChangeListener pcl) {
        listeners.add(pcl);
    }

    public void removePropertyChangeListener(PropertyChangeListener pcl) {
        listeners.remove(pcl);
    }

    private void fire(String propertyName, Object old, Object nue) {
        //Passing 0 below on purpose, so you only synchronize for one atomic call
        PropertyChangeListener[] pcls = (PropertyChangeListener[]) listeners.toArray(new PropertyChangeListener[0]);
        for (int i = 0; i < pcls.length; i++) {
            pcls[i].propertyChange(new PropertyChangeEvent(this,
                    propertyName, old, nue));
        }
    }
}

