/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.vu.nat.myeditor;

import nl.vu.nat.api.myapi.DatasetAPIObject;
import org.openide.nodes.Children;
import org.openide.nodes.Node;

/**
 *
 * @author joris
 */
class MyChildren extends Children.Keys {

    public MyChildren() {
    }

    @Override
    protected void addNotify() {
        DatasetAPIObject[] objs = new DatasetAPIObject[5];
        for (int i = 0; i < objs.length; i++) {
            objs[i] = new DatasetAPIObject();
        }
        setKeys(objs);
    }

    @Override
    protected Node[] createNodes(Object o) {
        DatasetAPIObject obj = (DatasetAPIObject) o;
        return new Node[]{new MyNode(obj)};
    }
}
