/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.vu.nat.myeditor;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import nl.vu.nat.api.myapi.DatasetAPIObject;
import org.openide.ErrorManager;
import org.openide.nodes.AbstractNode;
import org.openide.nodes.PropertySupport;
import org.openide.nodes.Sheet;
import org.openide.util.WeakListeners;
import org.openide.util.actions.Presenter;
import org.openide.util.lookup.Lookups;

/**
 *
 * @author joris
 */
public class MyNode extends AbstractNode implements PropertyChangeListener {

    public MyNode(DatasetAPIObject obj) {
        super(new MyChildren(), Lookups.singleton(obj));
        setDisplayName("APIObject " + obj.getIndex());
        obj.addPropertyChangeListener(WeakListeners.propertyChange(this, obj));
    }

    public MyNode() {
        super(new MyChildren());
        setDisplayName("Root");
    }

    @Override
    public String getHtmlDisplayName() {
        DatasetAPIObject obj = (DatasetAPIObject) getLookup().lookup(DatasetAPIObject.class);
        if (obj != null) {
            return "<font color='!textText'>APIObject " + obj.getIndex() + "</font>" +
                    "<font color='!controlShadow'><i>" + obj.getDate() + "</i></font>";
        } else {
            return null;
        }
    }
//    public Image getIcon (int type) {
//    return Utilities.loadImage ("org/myorg/myeditor/icon.gif");
//    }
    @Override
    public Action[] getActions(boolean popup) {
        return new Action[]{new MyAction()};
    }

    private class MyAction extends AbstractAction implements Presenter.Popup {

        public MyAction() {
            putValue(NAME, "Do Something");
        }

        public void actionPerformed(ActionEvent e) {
            DatasetAPIObject obj = (DatasetAPIObject) getLookup().lookup(DatasetAPIObject.class);
            JOptionPane.showMessageDialog(null, "Hello from " + obj);
        }

        public JMenuItem getPopupPresenter() {
            JMenu result = new JMenu("Submenu");  //remember JMenu is a subclass of JMenuItem
            result.add(new JMenuItem(this));
            result.add(new JMenuItem(this));
            return result;

        }
    }

    public void propertyChange(PropertyChangeEvent evt) {
        if ("date".equals(evt.getPropertyName())) {
            this.fireDisplayNameChange(null, getDisplayName());
        }
    }

    @Override
    protected Sheet createSheet() {
        Sheet sheet = Sheet.createDefault();
        Sheet.Set set = sheet.createPropertiesSet();
        DatasetAPIObject obj = (DatasetAPIObject) getLookup().lookup(DatasetAPIObject.class);
        try {
           Property indexProp = new PropertySupport.Reflection(obj, Integer.class,
                    "getIndex", null);
            Property dateProp = new PropertySupport.Reflection(obj, Date.class,
                    "getDate", null);

            indexProp.setName("index");
            dateProp.setName("date");
            set.put(indexProp);
            set.put(dateProp);
        } catch (NoSuchMethodException ex) {
            ErrorManager.getDefault().notify(ex);
        }
        sheet.put(set);
        return sheet;
    }
}
