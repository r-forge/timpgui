/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.vu.nat.myeditor;

import nl.vu.nat.api.myapi.DatasetAPIObject;
import org.openide.nodes.Children;
import org.openide.nodes.Node;

/**
 *
 * @author joris
 */
class NodeChilderen extends Children.Keys {

    public NodeChilderen() {
    }

    @Override
    protected void addNotify() {
//        DatasetAPIObject[] objs = new DatasetAPIObject[1];
//        for (int i = 0; i < objs.length; i++) {
//            objs[i] = new DatasetAPIObject();
//        }
        DatasetAPIObject[] objs = new DatasetAPIObject[1];
        objs[0] = new DatasetAPIObject();
        setKeys(objs);
    }

    @Override
    protected Node[] createNodes(Object o) {
        DatasetAPIObject obj = (DatasetAPIObject) o;
        return new Node[]{new DatasetNode(obj)};
    }
}
